# Colorpicker plugin for Twitter Bootstrap

Originally written by [Stefan Petre](http://www.eyecon.ro/)

Read the documentation [here](http://xaguilars.github.com/bootstrap-colorpicker/)


## Contributors

Please, before perform a Pull Request:

* Check that the index.html demos aren't broken (modify if necessary)
* Test your code in all modern browsers (and at least IE >= 9)
* Stable branch = master; all new stuff goes to 'develop' branch

Thank you